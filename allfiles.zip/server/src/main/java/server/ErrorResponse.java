package server;

public record ErrorResponse(String message){ }