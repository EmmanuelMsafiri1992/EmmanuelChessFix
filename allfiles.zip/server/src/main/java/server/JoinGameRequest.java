package server;

public record JoinGameRequest(int gameID, String playerColor){ }