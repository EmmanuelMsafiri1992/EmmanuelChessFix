package server;

public record GameResponse(int gameID){ }