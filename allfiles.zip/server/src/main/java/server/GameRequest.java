package server;

public record GameRequest(String gameName){ }